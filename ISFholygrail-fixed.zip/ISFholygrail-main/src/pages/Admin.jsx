import { useEffect, useState } from 'react'

async function callAdmin(password, action, payload) {
  const res = await fetch('/api/admin', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password, action, payload }),
  })
  let json
  try {
    json = await res.json()
  } catch {
    json = { ok: false, error: `Server returned ${res.status}` }
  }
  return json
}

const TABS = ['Flagged', 'All posts', 'All files', 'Requests', 'Feedback']

export default function Admin() {
  const [password, setPassword] = useState('')
  const [unlocked, setUnlocked] = useState(false)
  const [error, setError] = useState('')
  const [tab, setTab] = useState('Flagged')
  const [posts, setPosts] = useState([])
  const [files, setFiles] = useState([])
  const [requests, setRequests] = useState([])
  const [feedback, setFeedback] = useState([])
  const [loading, setLoading] = useState(false)
  const [tabError, setTabError] = useState('')

  async function loadPosts(onlyFlagged) {
    setLoading(true)
    setTabError('')
    const result = await callAdmin(password, 'list_posts', { onlyFlagged })
    if (result.ok) setPosts(result.data || [])
    else setTabError(result.error || 'Failed to load posts')
    setLoading(false)
  }

  async function loadFiles() {
    setLoading(true)
    setTabError('')
    const result = await callAdmin(password, 'list_files', {})
    if (result.ok) setFiles(result.data || [])
    else setTabError(result.error || 'Failed to load files')
    setLoading(false)
  }

  async function loadRequests() {
    setLoading(true)
    setTabError('')
    const result = await callAdmin(password, 'list_requests', {})
    if (result.ok) setRequests(result.data || [])
    else setTabError(result.error || 'Failed to load requests')
    setLoading(false)
  }

  async function loadFeedback() {
    setLoading(true)
    setTabError('')
    const result = await callAdmin(password, 'list_feedback', {})
    if (result.ok) setFeedback(result.data || [])
    else setTabError(result.error || 'Failed to load feedback')
    setLoading(false)
  }

  useEffect(() => {
    if (!unlocked) return
    if (tab === 'Flagged') loadPosts(true)
    if (tab === 'All posts') loadPosts(false)
    if (tab === 'All files') loadFiles()
    if (tab === 'Requests') loadRequests()
    if (tab === 'Feedback') loadFeedback()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [unlocked, tab])

  async function unlock() {
    setError('')
    const result = await callAdmin(password, 'ping', {})
    if (result.ok) {
      setUnlocked(true)
    } else {
      setError(result.error || 'Wrong password.')
    }
  }

  async function unhide(post) {
    const r = await callAdmin(password, 'unhide_post', { id: post.id })
    if (!r.ok) return setTabError(r.error || 'Failed to unhide')
    loadPosts(tab === 'Flagged')
  }

  async function deletePost(post) {
    const r = await callAdmin(password, 'delete_post', { id: post.id })
    if (!r.ok) return setTabError(r.error || 'Failed to delete')
    loadPosts(tab === 'Flagged')
  }

  async function deleteFile(file) {
    const r = await callAdmin(password, 'delete_file', { id: file.id })
    if (!r.ok) return setTabError(r.error || 'Failed to delete')
    loadFiles()
  }

  async function deleteRequest(request) {
    const r = await callAdmin(password, 'delete_request', { id: request.id })
    if (!r.ok) return setTabError(r.error || 'Failed to delete')
    loadRequests()
  }

  async function deleteFeedback(item) {
    const r = await callAdmin(password, 'delete_feedback', { id: item.id })
    if (!r.ok) return setTabError(r.error || 'Failed to delete')
    loadFeedback()
  }

  if (!unlocked) {
    return (
      <div className="max-w-sm mx-auto px-4 py-24 relative">
        <h1 className="font-display text-3xl mb-4">Admin</h1>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && unlock()}
          placeholder="Admin password"
          className="w-full font-body text-sm border border-ink/20 bg-parchment px-3 py-2 mb-3"
        />
        {error && <p className="font-body text-sm text-oxblood mb-2">{error}</p>}
        <button onClick={unlock} className="w-full bg-library text-parchment font-body text-sm py-2 shadow-card">
          Unlock
        </button>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 relative">
      <h1 className="font-display text-4xl mb-6">Admin</h1>

      <div className="flex flex-wrap gap-2 mb-6">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`stamp text-xs px-3 py-2 border ${tab === t ? 'bg-library text-parchment border-library' : 'border-ink/20 text-inkSoft'}`}
          >
            {t}
          </button>
        ))}
      </div>

      {loading && <p className="font-body text-sm text-inkSoft mb-3">Loading…</p>}
      {tabError && <p className="font-body text-sm text-oxblood mb-3">{tabError}</p>}

      {(tab === 'Flagged' || tab === 'All posts') && (
        <div className="space-y-4">
          {!loading && posts.length === 0 && <p className="font-body text-inkSoft">Nothing here.</p>}
          {posts.map((p) => (
            <div key={p.id} className="tilt-card bg-parchmentDark border border-ink/10 shadow-card p-5">
              <p className="stamp text-xs mb-1">
                {p.channel} · {p.flag_count || 0} flag(s) · {p.hidden ? 'hidden' : 'visible'} · {p.author_name}
              </p>
              <p className="font-body text-sm mb-3 whitespace-pre-wrap">{p.body}</p>
              <div className="flex gap-4">
                {p.hidden && <button onClick={() => unhide(p)} className="font-body text-sm text-library underline">Unhide / clear flags</button>}
                <button onClick={() => deletePost(p)} className="font-body text-sm text-oxblood underline">Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'All files' && (
        <div className="space-y-3">
          {!loading && files.length === 0 && <p className="font-body text-inkSoft">Nothing here.</p>}
          {files.map((f) => (
            <div key={f.id} className="tilt-card flex items-center justify-between bg-parchmentDark border border-ink/10 shadow-card p-4">
              <div>
                <p className="stamp text-xs mb-1">{f.type} · {f.grade} · {f.subject}</p>
                <p className="font-body text-sm">{f.title} — {f.uploader_name}</p>
              </div>
              <button onClick={() => deleteFile(f)} className="font-body text-sm text-oxblood underline shrink-0 ml-4">Delete</button>
            </div>
          ))}
        </div>
      )}

      {tab === 'Requests' && (
        <div className="space-y-3">
          {!loading && requests.length === 0 && <p className="font-body text-inkSoft">Nothing here.</p>}
          {requests.map((r) => (
            <div key={r.id} className="tilt-card flex items-center justify-between bg-parchmentDark border border-ink/10 shadow-card p-4">
              <div>
                <p className="stamp text-xs mb-1">{r.subject} · {r.status || 'open'} · ▲{r.upvotes || 0} ▼{r.downvotes || 0}</p>
                <p className="font-body text-sm">{r.description}</p>
              </div>
              <button onClick={() => deleteRequest(r)} className="font-body text-sm text-oxblood underline shrink-0 ml-4">Delete</button>
            </div>
          ))}
        </div>
      )}

      {tab === 'Feedback' && (
        <div className="space-y-3">
          {!loading && feedback.length === 0 && <p className="font-body text-inkSoft">Nothing here.</p>}
          {feedback.map((f) => (
            <div key={f.id} className="tilt-card flex items-start justify-between gap-4 bg-parchmentDark border border-ink/10 shadow-card p-4">
              <div>
                <p className="stamp text-xs text-inkSoft mb-1">{new Date(f.created_at).toLocaleDateString()}</p>
                <p className="font-body text-sm whitespace-pre-wrap">{f.message}</p>
              </div>
              <button onClick={() => deleteFeedback(f)} className="font-body text-sm text-oxblood underline shrink-0">Delete</button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
